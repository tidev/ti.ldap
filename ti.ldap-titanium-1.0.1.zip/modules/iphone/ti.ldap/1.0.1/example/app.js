// Sample application to demonstrate the capabilities of the LDAP module

var navigator = require('utility/navigator').openAppWindow({
	viewName: 'connect'
});



